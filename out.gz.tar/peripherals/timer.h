#ifndef TIMER_H
#define TIMER_H
#include "../types/common.h"

void set_timer(u32_t time, u32_t nth);
u64_t get_time();
#endif