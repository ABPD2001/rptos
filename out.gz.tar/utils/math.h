#ifndef MATH_H
#define MATH_H
#include "../types/common.h"

extern u32_t min(u32_t v1, u32_t v2);
extern u32_t max(u32_t v1, u32_t v2);
#endif