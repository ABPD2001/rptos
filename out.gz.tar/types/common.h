#ifndef TYPES_H
#define TYPES_H

#define GPIO_BASE 0x7E20
#define GPIO_GPFSEL0 0x0
#define GPIO_GPFSEL1 0x4
#define GPIO_GPFSEL2 0x8
#define GPIO_GPFSEL3 0xC
#define GPIO_GPFSEL4 0x10
#define GPIO_GPFSEL5 0x14

#define GPIO_GPSET0 0x001C
#define GPIO_GPSET1 0x0020

#define GPIO_GPCLR0 0x0028
#define GPIO_GPCLR1 0x002C

#define SYSTEM_STAT 0x1B30
#define MINI_UART_LICENSE 0x1B10
#define MINI_UART_BASE 0x7E21
#define MINI_UART_STAT 0x5064
#define MINI_UART_MU_IO 0x5040
#define MINI_UART_BAUDRATE 0x5068
#define MINI_UART_IIR 0x5044
#define MINI_UART_LSR 0x5054
#define MINI_UART_MU_CNTL 0x5060
#define MINI_UART_PREF 0x5004
#define MINI_UART_LCR 0x504C

#define MINI_UART_LICENSE_RX_BUFFER_STAT 0xE
#define MINI_UART_LICENSE_OWNED_TASK_ID 0xC
#define MINI_UART_LICENSE_BARE_STATUS 0xB
#define MINI_UART_LICENSE_BAUDRATE 0xA
#define MINI_UART_LICENSE_RX_BUFFER_SIZE 0x8
#define MINI_UART_LICENSE_RX_BUFFER_LEN 0x4
#define MINI_UART_LICENSE_RX_BUFFER 0x0

#define TIMER_BASE 0x7E0030000
#define TIMER_CLO 0x4
#define TIMER_CHI 0x8
#define TIMER_C0 0xC

#define NULL 0

typedef unsigned char ubyte_t;
typedef unsigned short int u16_t;
typedef unsigned int u32_t;
typedef unsigned long u64_t;
#endif